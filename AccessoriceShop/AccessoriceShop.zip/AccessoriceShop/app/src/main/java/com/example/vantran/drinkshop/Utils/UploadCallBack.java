package com.example.vantran.drinkshop.Utils;

/**
 * Created by vandongluong on 10/21/18.
 */

public interface UploadCallBack {
    void onProgressUpdate(int pertanage);
}
