package com.example.vantran.drinkshop.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by vandongluong on 10/29/18.
 */

public class Result {
    @SerializedName("message_id")
    @Expose
    public String message_id;
}
