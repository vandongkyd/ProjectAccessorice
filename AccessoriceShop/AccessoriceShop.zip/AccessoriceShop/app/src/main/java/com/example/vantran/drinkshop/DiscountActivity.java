package com.example.vantran.drinkshop;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DiscountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discount);
    }
}
