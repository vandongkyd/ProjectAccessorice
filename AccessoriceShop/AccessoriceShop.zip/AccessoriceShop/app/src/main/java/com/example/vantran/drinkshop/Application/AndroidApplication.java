package com.example.vantran.drinkshop.Application;

import android.app.Application;


/**
 * Created by vandongluong on 10/18/18.
 */

public class AndroidApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }

}
