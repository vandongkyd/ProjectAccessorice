package com.example.vantran.drinkshop.Utils;

/**
 * Created by vandongluong on 11/10/18.
 */

public class Config {
    public static final String KEY_CLIENT_PAYPAL_ID = "AbwUtWIVr7VYC2k7PgzuC_U9iArPyGP8dH0IR_kPuQ9kDV9T2cCt4-KyQnPL9QuAFtadnQaXeZ2QarlJ";
}
